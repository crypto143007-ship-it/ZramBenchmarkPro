package com.zrambenchmark.pro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZramApp(this) }
    }
}

private enum class Page(val label: String) { Dashboard("Dashboard"), Algorithms("Algorithms"), Benchmark("Benchmark"), System("System info"), Results("Results") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ZramApp(activity: MainActivity) {
    var page by remember { mutableStateOf(Page.Dashboard) }
    var snapshot by remember { mutableStateOf(BenchmarkEngine.snapshot(activity)) }
    val algorithms = remember { BenchmarkEngine.detectAlgorithms() }
    var result by remember { mutableStateOf<BenchmarkResult?>(null) }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var job by remember { mutableStateOf<Job?>(null) }
    var rounds by remember { mutableIntStateOf(5) }
    var size by remember { mutableIntStateOf(8) }
    val scope = rememberCoroutineScope()
    val dark = isSystemInDarkTheme()
    val colors = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF75D7C5), secondary = androidx.compose.ui.graphics.Color(0xFF9DB9FF), background = androidx.compose.ui.graphics.Color(0xFF080B10), surface = androidx.compose.ui.graphics.Color(0xFF111720)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF006B5B), secondary = androidx.compose.ui.graphics.Color(0xFF435F91))

    MaterialTheme(colorScheme = colors) {
        Scaffold(
            topBar = { TopAppBar(title = { Column { Text("ZRAM Benchmark Pro", fontWeight = FontWeight.Bold); Text("Kernel-aware performance lab", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }, actions = { IconButton(onClick = { snapshot = BenchmarkEngine.snapshot(activity) }) { Icon(Icons.Default.Refresh, "Refresh system data") } }) },
            bottomBar = { NavigationBar { Page.values().forEach { p -> NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(when (p) { Page.Dashboard -> Icons.Default.Dashboard; Page.Algorithms -> Icons.Default.Memory; Page.Benchmark -> Icons.Default.Speed; Page.System -> Icons.Default.PhoneAndroid; Page.Results -> Icons.Default.Assessment }, p.label) }, label = { Text(p.label) }) } } }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(MaterialTheme.colorScheme.background)) {
                when (page) {
                    Page.Dashboard -> Dashboard(snapshot, result, algorithms.size, onStart = { page = Page.Benchmark })
                    Page.Algorithms -> AlgorithmsPage(algorithms)
                    Page.Benchmark -> BenchmarkPage(running, status, rounds, size, { rounds = it }, { size = it }, onRun = {
                        if (!running) {
                            running = true; status = "Warming up and measuring standalone DEFLATE…"
                            job = scope.launch {
                                try { result = BenchmarkEngine.runStandalone(rounds, size) { !running }; status = "Completed · round-trip verified" }
                                catch (e: Exception) { status = e.message ?: "Benchmark failed" }
                                finally { running = false; snapshot = BenchmarkEngine.snapshot(activity) }
                            }
                        }
                    }, onCancel = { running = false; job?.cancel() })
                    Page.System -> SystemPage(snapshot)
                    Page.Results -> ResultsPage(result, onExport = { r ->
                        if (r != null) {
                            val csv = "algorithm,domain,original_bytes,compressed_bytes,ratio,saved_bytes,compression_MBps,decompression_MBps,compression_cpu_ms,decompression_cpu_ms,repetitions,median_compression_ms,median_decompression_ms\n" +
                                listOf(r.algorithm, r.domain, r.originalBytes, r.compressedBytes, r.ratio, r.savedBytes, r.compressionMBps, r.decompressionMBps, r.compressionCpuMs, r.decompressionCpuMs, r.repetitions, r.medianCompressionMs, r.medianDecompressionMs).joinToString(",")
                            val send = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_TEXT, csv)
                            try { activity.startActivity(Intent.createChooser(send, "Share benchmark CSV")) } catch (_: Exception) { status = "Export unavailable" }
                        }
                    })
                }
            }
        }
    }
}

@Composable
private fun Dashboard(s: SystemSnapshot, r: BenchmarkResult?, algorithmCount: Int, onStart: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(18.dp)) { Text("BENCHMARK WORKSPACE", style = MaterialTheme.typography.labelMedium); Spacer(Modifier.height(6.dp)); Text("Measure what your kernel actually supports.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Kernel discovery is read-only. Standalone tests are clearly separated from real ZRAM measurements."); Spacer(Modifier.height(14.dp)); Button(onClick = onStart) { Icon(Icons.Default.PlayArrow, null); Text("  Run benchmark") } } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Active algorithm", s.currentAlgorithm, Modifier.weight(1f)); MetricCard("ZRAM size", s.zramSize, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("RAM available", if (s.totalRamKb > 0) "${s.availableRamKb / 1024} MB" else "Unavailable", Modifier.weight(1f)); MetricCard("Algorithms found", algorithmCount.toString(), Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Battery", s.batteryPct?.let { "$it%" } ?: "Unavailable", Modifier.weight(1f)); MetricCard("Battery temp", s.batteryTempC?.let { "${it}°C" } ?: "Unavailable", Modifier.weight(1f)) } }
        item { SectionTitle("Latest measurement") }
        item { if (r == null) InfoCard("No benchmark yet", "Run a standalone test to create the first verified result. Kernel algorithms are discovered separately and are not silently switched.") else InfoCard("${r.algorithm} · ${r.domain}", "Compression ${fmt(r.compressionMBps)} MB/s · Decompression ${fmt(r.decompressionMBps)} MB/s · Ratio ${fmt(r.ratio)}×") }
        item { Text("Accuracy note: Android generally does not expose per-process hardware energy, kernel ZRAM codec timing, or CPU cycles to ordinary apps. Those fields are not inferred here.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun AlgorithmsPage(items: List<AlgorithmInfo>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { InfoCard("Dynamic detection", "Names are read from /sys/block/zram*/comp_algorithm when accessible. A listed kernel codec is only advertised as available; this app does not claim it has benchmarked it.") }
        items(items) { a -> Card { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(a.name, fontWeight = FontWeight.SemiBold); Text(a.domain, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(a.detail, style = MaterialTheme.typography.bodySmall) }; AssistChip(onClick = {}, label = { Text(if (a.available) "Detected" else "Unavailable") }) } } }
        item { Text("zsmalloc, zbud and z3fold are memory allocators, not compression algorithms; they are intentionally not shown as codecs.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun BenchmarkPage(running: Boolean, status: String, rounds: Int, size: Int, setRounds: (Int) -> Unit, setSize: (Int) -> Unit, onRun: () -> Unit, onCancel: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Standalone benchmark") }
        item { InfoCard("What is measured", "The initial engine tests JDK DEFLATE with identical deterministic mixed-content data, warm-up, repeated compression/decompression, and byte-for-byte round-trip verification. It is not a kernel ZRAM benchmark.") }
        item { Card { Column(Modifier.padding(16.dp)) { Text("Dataset size: $size MiB"); Slider(value = size.toFloat(), onValueChange = { setSize(it.toInt()) }, valueRange = 1f..32f, steps = 30); Text("Measured repetitions: $rounds"); Slider(value = rounds.toFloat(), onValueChange = { setRounds(it.toInt()) }, valueRange = 1f..20f, steps = 18); Text("One warm-up round is excluded from the reported sample set.", style = MaterialTheme.typography.bodySmall) } } }
        item { Button(onClick = onRun, enabled = !running, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Text("  Start benchmark") } }
        if (running) item { OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Stop, null); Text("  Cancel") } }
        item { LinearProgressIndicator(if (running) { 0.55f } else 1f, Modifier.fillMaxWidth()) }
        item { Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("Safety: standalone compression only. No swapoff, no zram reset, no algorithm write, no memory-exhaustion test.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun SystemPage(s: SystemSnapshot) {
    val rows = listOf("Device" to s.device, "Android" to s.android, "Kernel" to s.kernel, "ABI" to s.abi, "CPU cores" to s.cores.toString(), "Total RAM" to "${s.totalRamKb / 1024} MB", "Available RAM" to "${s.availableRamKb / 1024} MB", "ZRAM device" to s.zramDevice, "ZRAM size" to s.zramSize, "Active codec" to s.currentAlgorithm, "Battery" to (s.batteryPct?.let { "$it%" } ?: "Unavailable"), "Battery temperature" to (s.batteryTempC?.let { "${it} °C" } ?: "Unavailable"), "Battery current" to (s.batteryCurrentUa?.let { "$it µA (BatteryManager; sign is device-dependent)" } ?: "Unavailable"), "Battery voltage" to (s.batteryVoltageMv?.let { "$it mV" } ?: "Unavailable"))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(rows) { (k, v) -> Card { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(12.dp)); Text(v, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)) } } }
        item { InfoCard("/sys/block/zram*/mm_stat", s.mmStat) }
        item { InfoCard("/proc/swaps", s.swaps) }
    }
}

@Composable
private fun ResultsPage(r: BenchmarkResult?, onExport: (BenchmarkResult?) -> Unit) {
    if (r == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No results yet") }; return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionTitle("Verified benchmark result") }
        item { InfoCard("${r.algorithm} · ${r.domain}", "Dataset ${r.originalBytes / 1048576} MiB · ${r.repetitions} repetitions · round-trip verified") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { MetricCard("Compression", "${fmt(r.compressionMBps)} MB/s", Modifier.weight(1f)); MetricCard("Decompression", "${fmt(r.decompressionMBps)} MB/s", Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { MetricCard("Ratio", "${fmt(r.ratio)}×", Modifier.weight(1f)); MetricCard("Saved", "${r.savedBytes / 1024} KiB", Modifier.weight(1f)) } }
        item { MetricCard("Compressed size", "${r.compressedBytes / 1024} KiB", Modifier.fillMaxWidth()) }
        item { MetricCard("Median compression / decompression", "${fmt(r.medianCompressionMs)} ms / ${fmt(r.medianDecompressionMs)} ms", Modifier.fillMaxWidth()) }
        item { MetricCard("Thread CPU time (avg per operation)", "${fmt(r.compressionCpuMs)} ms / ${fmt(r.decompressionCpuMs)} ms", Modifier.fillMaxWidth()) }
        item { Text("CPU time is process thread CPU time from Android Debug; it is not whole-device CPU utilization or hardware cycles.", style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { onExport(r) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text("  Export CSV") } }
    }
}

@Composable private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier) { Column(Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(6.dp)); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } } }
@Composable private fun InfoCard(title: String, body: String) { Card { Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text(body, style = MaterialTheme.typography.bodyMedium) } } }
@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
private fun fmt(v: Double) = "%.2f".format(v)
