# ZRAM Benchmark Pro — initial engineering build (0.1.0)

This is a real Android Studio project. It is an intentionally conservative first milestone, not a claim that every item in the original feature list is already implemented.

## Implemented
- Jetpack Compose + Material 3 multi-screen interface (Dashboard, Algorithms, Benchmark, System info, Results).
- Dynamic discovery of codec names from readable `/sys/block/zram*/comp_algorithm` files.
- Explicit distinction between kernel-advertised algorithms and a measured standalone codec.
- Correct classification note: `zsmalloc`, `zbud`, and `z3fold` are allocators, not compression codecs.
- Read-only collection of `/proc/meminfo`, `/proc/swaps`, ZRAM `mm_stat`, ZRAM size and active codec when readable, Android build/ABI, battery level/temperature/current/voltage.
- A deterministic mixed-content standalone DEFLATE benchmark with one warm-up, repeated measurements, median latency, throughput, thread CPU time, compression ratio, memory saved, and byte-for-byte decompression verification.
- CSV sharing through Android Sharesheet.
- No root requirement and no writes to ZRAM/sysfs.

## Important limitations in this milestone
- The only actually benchmarked codec is Java's `java.util.zip` DEFLATE implementation. It is **not** a ZRAM kernel benchmark and must not be compared as if it were LZ4/ZSTD kernel performance.
- Kernel codecs are discovered but not switched or benchmarked. Safely benchmarking kernel ZRAM requires a separately provisioned scratch ZRAM device (or another explicitly isolated mechanism), sufficient memory headroom, verified cleanup/restoration, and root. The app deliberately does not repurpose active swap.
- Battery current is a device-reported instantaneous value; battery percentage deltas are not converted into precise energy. Whole-device power, hardware CPU cycles, per-core utilization, and kernel codec timing are not claimed.
- The first milestone does not yet include Room history, PDF/JSON export, workload simulation, thermal throttling analysis, custom weighting, or stress tests.

## Build

Requirements: Android SDK Platform 36, Build Tools 36.x, JDK 17+, Android Gradle Plugin 8.13.2, Kotlin 2.2.20, Gradle 8.13.

From this directory:

```sh
gradle --version
gradle :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

Install with:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

If building in Termux, use your installed Android SDK and JDK 21. The Android Gradle Plugin version above expects Gradle 8.13; use a Gradle 8.13 wrapper/distribution rather than assuming Gradle 9.6 is compatible with AGP 8.13.2.

## Result interpretation

Compression ratio = original bytes / compressed bytes.

Memory saved = original bytes − compressed bytes.

Compression throughput = original input bytes / compression wall-clock time.

Decompression throughput = decompressed output bytes / decompression wall-clock time.

CPU time comes from `Debug.threadCpuTimeNanos()` for the benchmark thread. It is not total system CPU utilization.
